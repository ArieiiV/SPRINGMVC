package srm.srmassset.pojos;

public class PojoExample {

}
